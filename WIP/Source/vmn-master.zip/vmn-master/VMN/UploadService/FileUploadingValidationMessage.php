<?php

namespace VMN\UploadService;

interface FileUploadingValidationMessage
{
    public function toString();
}