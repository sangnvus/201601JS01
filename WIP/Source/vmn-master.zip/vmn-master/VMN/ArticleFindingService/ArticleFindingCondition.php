<?php

namespace VMN\ArticleFindingService;

interface ArticleFindingCondition
{
    public function getQuery();
}
