<?php

namespace VMN\ArticleFindingService;

interface PaginatableCondition
{
    public function setPage($page);
}