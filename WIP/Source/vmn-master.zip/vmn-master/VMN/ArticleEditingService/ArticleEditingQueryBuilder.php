<?php

namespace VMN\ArticleEditingService;

use Illuminate\Support\Facades\DB;

class ArticleEditingQueryBuilder
{
    public function addHistoryPlants($plantRaw)
    {

    }
}

/*
 * 'commonName',
            'otherName',
            'scienceName',
            'characteristic',
            'location',
            'utility',
            'ratingPoint',
            'author',
            'thumbnailUrl',
            'imgUrl',
 * */