<?php

namespace VMN\ArticleReviewService;

class Rating
{

}