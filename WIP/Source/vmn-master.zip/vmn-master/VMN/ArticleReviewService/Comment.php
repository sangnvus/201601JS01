<?php

namespace VMN\ArticleReviewService;

class Comment
{

}