<?php
/**
 * Created by PhpStorm.
 * User: tientoantai
 * Date: 03/03/2016
 * Time: 10:19
 */

namespace VMN\Auth;



class Mod extends Member
{

}