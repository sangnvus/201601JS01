<?php

namespace VMN\Auth;


class RegistrationValidator
{
    public function validate(Credential $credential)
    {
        if( $credential->all() )
        {

        }
    }
}