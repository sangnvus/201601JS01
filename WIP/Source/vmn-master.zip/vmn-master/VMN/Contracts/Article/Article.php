<?php

namespace VMN\Contracts\Article;

interface Article
{
    public function id();
}
